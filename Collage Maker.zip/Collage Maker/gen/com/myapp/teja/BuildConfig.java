/** Automatically generated file. DO NOT MODIFY */
package com.myapp.teja;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}